package ServiceBilling.Services;

public class ECG extends Service {

    public ECG() {
        super(200.40);
    }
}
