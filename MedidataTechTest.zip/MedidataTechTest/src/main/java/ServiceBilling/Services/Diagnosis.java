package ServiceBilling.Services;

public class Diagnosis extends Service {


    public Diagnosis() {
        super(60.0);
    }


}
