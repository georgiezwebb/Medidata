package ServiceBilling.Services;

public class XRay extends Service {

    public XRay() {
        super(150.00);
    }
}
